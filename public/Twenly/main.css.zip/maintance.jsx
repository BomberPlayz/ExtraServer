exports.run = (request, response, args, fs) => {
    let mt = true
    response.end(mt.toString())
}