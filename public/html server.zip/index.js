var http = require('http');
var fs = require('fs');

let data = "noob"

const p=require("./config.json");
const CFG = p[data]
const PORT = CFG.port

http.createServer(function(request, response) {
    console.log(request.headers.host + ": requested to: ." + request.url);
    if (request.url == "/") {
      var file2 = fs.readFileSync("./index.html")
      response.writeHeader(200, {"Content-Type": "text/html"});
      response.write(file2);
      response.end();
    } else {
      if (fs.existsSync("." + request.url)) {
        var file = fs.readFileSync("." + request.url)
        response.writeHeader(200, {"Content-Type": "text/html"});
        response.write(file);
        response.end();
      } else {
        console.log("sorry this file not found!");
        response.writeHeader(200, {"Content-Type": "text/html"});
        var file1 = fs.readFileSync("./40.html")
        response.write(file1)
        response.end();
      }
    }
}).listen(PORT);
console.log("lisening on: http://*:" + PORT);
